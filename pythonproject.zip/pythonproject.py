import requests
from bs4 import BeautifulSoup
import csv
from itertools import zip_longest
jobs=[]
companyname=[]
locations=[]
skills=[]
links=[]
salary=[]
date=[]
page_num=0
while True:
    try:
        result=requests.get(f"https://wuzzuf.net/search/jobs/?a=hpb&q=python&start={page_num}")
        src=result.content
        soup=BeautifulSoup(src,"lxml")
        page_limit=int(soup.find("strong").text)
        if(page_num>page_limit//15):
            print("pages ended, terminate")
            break
        job_title=soup.find_all("h2",{"class" :"css-m604qf"})
        company_names=soup.find_all("a",{"class":"css-17s97q8"})
        locations_names=soup.find_all("span",{" class":"css-5wys0k"})
        job_skills=soup.find_all("div",{"class":"css-y4udm8"})
        posted_new=soup.find_all("span",{"class":"css-4c4ojb"})
        posted_old=soup.find_all("span",{"class":"css-do6t5g"})
        posted=[*posted_new,*posted_old]
        for i in range(len(job_title)):
            jobs.append(job_title[i].text)
            links.append(job_title[i].find("a").attrs['href'])
            companyname.append(company_names[i].text)
            locations.append(locations_names[i].text)
            skills.append(job_skills[i].text)
            date_text=posted[i].text.replace("-","").strip()
            date.append(date_text)
        page_num+=1
        print("page switched")
    except:
        print("error occurred")
        break
for link in links:
    result = requests.get(link)
    src=result.content
    soup=BeautifulSoup(src,"lxml")
    salaries=soup.find("span ",{"class":"css-47jx3m"})
    salary.append(salaries.text.strip())
with open("/Users/ahmed/Downloads/pythonproject.csv","w") as pythonproject:
    file_list=[jobs,companyname,locations,skills,links,salary,date]
    exported=zip_longest(*file_list)
    wr=csv.writer(pythonproject)
    wr.writerow(["jobs","companyname","locations","skills","links","salaries","date"])
    wr.writerows(exported)